// JAVASCRIPT - JQUERY - JQUERY MOBILE - PHONEGAP

//PHONEGAP
/*var app = {
    // Construtor de aplicação;
    initialize: function() {

        this.bindEvents();

    },


    // EVENTOS
    // Registro dos eventos que são necessários na inicialização do aplicativo.
    // Os mais comuns são:
    // 'load', 'deviceready', 'offline', e 'online'.    
    bindEvents: function() {

        document.addEventListener('deviceready', this.onDeviceReady, false);

    },

    // Manipulador do evento deviceready.
    // Os mais comuns são:
    // 'load', 'deviceready', 'offline', e 'online'.
    onDeviceReady: function() {

        app.receivedEvent('deviceready');

    },

    // Update DOM em um evento recebido.
    receivedEvent: function(id) {

        var parentElement = document.getElementById(id);
        var listeningElement = parentElement.querySelector('.listening');
        var receivedElement = parentElement.querySelector('.received');
        listeningElement.setAttribute('style', 'display:none;');
        receivedElement.setAttribute('style', 'display:block;');
        console.log('Received Event: ' + id);
    }
};*/

// Nosso script.
$(document).ready(function(){

    // Inserindo o nome de usuário nos painéis.
    $("#ok_btn").click(function(){
        var pega_nome = document.getElementById("input_nome").value;
        $("#nome_1").append(pega_nome);
        $("#nome_2").append(pega_nome);
        $("#nome_3").append(pega_nome);
        $("#nome_4").append(pega_nome);
    })

    //Criamos estas listas para ajudar na organização. O nosso objetivo é adicionar apenas 1 elemento por vez a cada cadastro alimentar e logo que o usuário
    //salvar, a gente limpa essas listas, tornando-as vazias novamente. É uma boa maneira também para serem realizadas algumas verificações. A gente sempre 
    //pegará o primeiro elemento da lista!
    var lista_refeicoes = [];
    var lista_sentimentos = [];
    var lista_fome = [];
    var lista_saciedade = [];
    var lista_informacao_adicional = [];

    // Acessando a refeição através de uma classe criada para as li's.
    $(".refeicao").click(function(){

        // Uma variavel que armazena o "texto" da li.
        var pega_refeicao = $(this).text();
        // Inserindo refeição na lista.
        lista_refeicoes.unshift(pega_refeicao);
    })

    // Acessando o sentimento através de uma classe criada para as li's.
    $(".sentimento").click(function(){
        // Uma variavel que armazena o "texto" da li.
        var pega_sentimento = $(this).text();
        // Inserindo refeição na lista.
        lista_sentimentos.unshift(pega_sentimento);
    })

    // Se caso o usuário salvar.
    $("#btn_salvar").click(function(){
        var pega_fome = document.getElementById("fome").value;
        lista_fome.unshift(pega_fome);
        var pega_saciedade = document.getElementById("saciedade").value;
        lista_saciedade.unshift(pega_saciedade);
        var pega_inf_adicio = document.getElementById("inf_adicio_input").value;
        lista_informacao_adicional.unshift(pega_inf_adicio);

        var tempo = new Date();
        var dia = tempo.getDate();
        var ano = tempo.getFullYear();
        var mes = tempo.getMonth() + 1;

        // horas
        var horas = tempo.getHours(); 
        var minutos = tempo.getMinutes();

        // <p id='title_refeicao'></p>
        // Após pegarmos os elementos/informações do usuário e armazenarmos em uma lista, adicionamos esses dados dentro de uma div dinamicamente atraves do JS/Jquery.
        $("#content").append("<div class='ui-body ui-body-a ui-corner-all'><b>Refeição:</b> " + lista_refeicoes[0] + "<br><b>Sentimento:</b> " + lista_sentimentos[0] + "<br><b>Fome:</b> " + lista_fome[0] + "<br><b>Saciedade: </b>" + lista_saciedade[0] + "<br><b>Informação Adicional:</b> " + lista_informacao_adicional[0] + "<br><b>Data:</b> " + dia+'/'+mes+'/'+ano + " " + "às" + " " + horas + ":" + minutos +"</div><hr>");
        $("#title_refeicao").append(lista_refeicoes[0]);

        // Verificações após salvar o conteúdo.
        // Limpando o input.
        var pega_inf_adicio = document.getElementById("inf_adicio_input").value = "";

        // Limpando as listas.
        lista_refeicoes = [];
        lista_sentimentos = [];
        lista_fome = [];
        lista_saciedade = [];
        lista_informacao_adicional = [];

        // Limpando os ranges.
        document.getElementById("form").reset();
    })

    // Se caso o usuário não quiser salvar a sua anotação a gente limpa as listas de qualquer forma.
    $("#btn_cancelar").click(function(){
        // Só limpamos essas duas listas pois as outras 3 ficam vazias até que o usuário clique em salvar.
        lista_refeicoes = [];
        lista_sentimentos = [];
    })

})

// CAMÊRA 
/*alert("oi");
$(document).ready(function(){
    $("#tirarFoto").click(function(){
        alert("Estou pronta para tirar a foto!");
        //Função que tira a foto.
        tirarFoto();
    });
});
document.addEventListener("deviceready");

function tirarFoto(){
    //Opções da câmera.
    var cameraOptions = {quality: 100, destinationType: Camera.DestinationType.FILE_URI};
    //Acessando os Plugins da Câmera.
    navigator.camera.getPicture(fotoTiradaSucesso, fotoTiradaFracasso, cameraOptions);
    alert("tirando foto");

}

//Se ocorrer tudo certo com o processamento da imagem.
function fotoTiradaSucesso(imgURI) {
    alert("imgURI: " + imgURI);
    var fotos = $("#fotos");
    var img = fotos.add("img").css("width: 100%");
    img.attr("src", imgURI);
}

//Se caso ocorrer um erro no prcessamento da imagem.
function fotoTiradaFracasso(message) {
    alert("Falhou por: " + message);
}*/